

Q4func <- function(x, s) {
  res = list()
  for(i in 1:length(x)){
    if(x[i] >= 0 & x[i] <= s) {res[i] = (3*sqrt(x[i]))/(2*s^(3/2))} else res[i] = 0
  }
  return(res)
}

plot(x=seq(0,3,0.01), 
     y=Q4func(seq(0,3,0.01), 1), 
     type = "l", 
     col = "red", 
     main = "PDF of X",
     xlab = "x",
     ylab = "P(X=x|s)")
lines(x=seq(0,3,0.01), y=Q4func(seq(0,3,0.01), 2), type = "l", col = "blue")
legend(x = 2.2, y = 1.25, c("s=1", "s=2"), lty = c(1,1), col = c("red", "blue"))


covid <- read.csv("covid.19.recovery.csv")
MLE <- mean(covid$Recovery.Time)
MLE

1 - ppois(13, MLE)

theta <- ppois(12, MLE)
theta
1 - pbinom(1, 5, theta)

probs <- table(covid$Recovery.Time)/2586
plot(x = 1:40, y = dpois(1:40, MLE), col = "blue", main = "1. Probability for days until recovery", xlab = "Days till recovery", ylab = "Probability")
points(x = 1:40, y = probs, col = "red")
legend(x = 23, y = 0.09, c("Observed probabilities", "Poisson predicted probabilities"), pch = c("o", "o"), col = c("red", "blue"))

plot(x = as.numeric(probs), y = dpois(1:40, MLE), main = "2. Observed against predicted with reference line", xlab = "Observed probabilities", ylab = "Poisson predicted probabilities")
abline(0,1)
