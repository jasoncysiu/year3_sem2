##########################################
# R script: Studio 1 Code.R
# Project: FIT2086 - Modelling for Data Analysis
#
# Date: 30/07/2021
# Author: Sean Rong Keh
#
# Purpose: Studio 1 Code
##########################################


# 2 Introduction to R

1+1
(log(10) - 1/5) * 3
sin(pi^2)

1/2 * sqrt(1+cos(pi/2)) * log(10)

x <- 1
2 -> y
x = x+y

z = y*x
z

ls()

rm(x,y)

rm(list=ls())

?ls

apropos("med")


# Data Management in R

getwd()

setwd("C:/Users/Sean/Documents/Monash University/2021 Third Year/Semester 2/FIT2086 - Modelling for Data Analysis/Week 1")

heart <- read.csv("heart.csv", header = TRUE)

nrow(heart)
ncol(heart)

heart

head(heart)
head(heart, 10)

View(heart)

names(heart)

str(heart)

heart$AGE
heart[,"AGE"]
heart[,1]

heart[,c("AGE", "HD")]
heart[,c(1,14)]

heart[10:15,]
heart[c(10,11,12,13,14,15),]

heart[c(3,88), c("SEX", "CP")]
heart[10:50, c("RESTECG", "HD")]

heart[heart$SEX == 0, "AGE"]
heart[heart$CHOL < 150, c("SEX", "CP")]

heart[heart$SEX == 0 & heart$CHOL < 150, ]

heart$AC <- heart$AGE / heart$CHOL

heart$AC <- NULL


# 4 Descriptive Statistics in R

heart <- read.csv("heart.csv", header = TRUE)

mean(heart$AGE)
median(heart$AGE)
quantile(heart$AGE)
min(heart$AGE)
max(heart$AGE)
range(heart$AGE)
var(heart$AGE)
sd(heart$AGE)

summary(heart$AGE)
summary(heart)

table(heart$SEX)

heart$SEX <- factor(heart$SEX, labels = c("MALE", "FEMALE"), levels = c(0,1))

table(heart$SEX)

table(heart$SEX, heart$HD)

heart$HD <- factor(heart$HD, labels = c("NO", "YES"), levels = c(0,1))

table(heart$SEX, heart$HD)


# 6 Flow Control and Functions
i = 45
cat("The value of i is:", i, "\n")

for (x in 1:15) {if (x%%2 == 1) print(x)}

mydiv <- function(a,b) {
  return(a/b)
}
mydiv(10,3)

myfact <- function(n) {
  return(factorial(n))
}
myfact(5)

retval <- list()

retval$a = 1
retval$b = "you can store strings too"
retval$c = list()
retval$c$g = "You can store lists inside lists"

retval

mmr <- function(v) {
  temp = list()
  temp$min = min(v)
  temp$max = max(v)
  temp$range = max(v) - min(v)
  return(temp)
}
mmr(c(1,2,5,4,3))


# 7 Basic Examination of a Dataset in R
data("ToothGrowth")

summary(ToothGrowth)
var(ToothGrowth)

boxplot(ToothGrowth$len)
hist(ToothGrowth$len, xlab = "Length")

quantile(ToothGrowth$len, c(0.05, 0.25, 0.5, 0.75, 0.95))

plot(ToothGrowth$len, ToothGrowth$dose, xlab = "Tooth Length", ylab = "Dose")
cor(ToothGrowth$len, ToothGrowth$dose)


# 8 Categorical Data
mush <- read.csv("Mushroom.csv", header = TRUE)
tab = table(mush$cap.shape)
pie(tab)

table(mush$class, mush$cap.shape)
table(mush$class, mush$cap.surface)
table(mush$class, mush$cap.color)
table(mush$class, mush$odor)
table(mush$class, mush$population)
table(mush$class, mush$habitat)

# odor looks to be the most strongly associated


# 9 More descriptive statistics for numeric variables
wine <- read.csv("wine.csv", header = TRUE)

for (i in 1:(ncol(wine)-1)) {
  print(i)
  cat("Correlation between", names(wine)[i], "and quality =", cor(wine[,i], wine$quality), "\n")
}

# alcohol looks to be most strongly associated
# citric acid and free sulfur dioxide do not appear to have any association