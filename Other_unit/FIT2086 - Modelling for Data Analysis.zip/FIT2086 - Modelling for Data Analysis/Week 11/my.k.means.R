my.k.means <- function(X, k)
{
  # Convert the dataframe to a matrix
  X = as.matrix(X)
  
  q = ncol(X)
  n = nrow(X)
  
  # Pre-allocate matrix for distances
  d  = matrix(ncol = k, nrow = n)
  
  # Initial centroids
  mu = X[sample(n)[1:k], ]
  
  # cluster ...
  
  for (i in 1:100) {
    for (j in 1:k) {
      d[,j] = rowSums(sweep(X,2,mu[j,])^2)
    }
    
    w.cluster = max.col(-d)
  }
  
}
