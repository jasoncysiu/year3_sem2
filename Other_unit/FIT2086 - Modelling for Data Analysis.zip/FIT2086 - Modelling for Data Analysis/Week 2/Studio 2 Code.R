## 2 Binomial Distribution

# 1. That is the probability of seeing (n-m) failures
# 2. That is the probability of seeing m successes
# 3. That is the number of possible ways to order m successes and (n-m) failures
# 4. That is the probability of success m times and failing (n-m) times in a particular ordering
# 5. That is the probability that we will see i or more successes from n trials
# 6. 0.6875
     dbinom(2, 4, 0.5) + dbinom(3, 4, 0.5) + dbinom(4, 4, 0.5)
     1 - pbinom(1, 4, 0.5)
# 7. a) No. Unless there are only 2 candidates. 
#    b) Yes. Treat successful launch as success. 
#    c) No. There are 3 outcomes. 
#    d) No. It is continuous.
#    e) No. There are 6 outcomes. 
# 8. a) (0.5)^10 = 1/1024
#    b) (0.5)^10 = 1/1024
#    c) 0.6230469
        1 - pbinom(4, 10, 0.5)


## 3 Gaussian Distribution

# 1. a) 0.6826895
        pnorm(1) - pnorm(-1)
#    b) 0.02275013
        1 - pnorm(2)
#    c) 0.3085375
        1 - pnorm(2, 0, 4)
# 2. a) No. Discrete.
#    b) No. Discrete. 
#    c) Yes.
#    d) No. Poisson should be applied. 
#    e) Yes.
# 3. a) z = (5-3)/4 = 0.5; P(Z < 0.5) ~= 0.679076
#    b) z = (-4-3)/4 = -1.75; P(Z > -1.75) = 1 - P(Z < -1.75) ~= 0.038577
#    c) z1 = (2-3)/4 = -0.25; z2 = (7-3)/4 = 1; P(-0.25 < Z < 1) = P(Z < 1) - P(Z < -0.25) ~= 0.846907 - 0.390096 = 0.456811
        
        
## 4 Poisson Distribution
# 1. 1, 4, 10 respectively
# 2. a) 0.07326256
        (4^1) * exp(-4) / factorial(1)
#    b) 0.1465251
        (4^2) * exp(-4) / factorial(2)
#    c) 0.09157819
        (4^0) * exp(-4) / factorial(0) + (4^1) * exp(-4) / factorial(1)
# 3. a) 0.07326256
        dpois(1, 4)
#    b) 0.1465251
        dpois(2, 4)
#    c) 0.09157819
        ppois(1, 4)
#    d) 0.2148696
        1 - ppois(5, 4)
# 4. a) Yes.
#    b) No.
#    c) Yes.
#    d) No.
#    e) No.
#    f) Yes.
# 5. a) 0.0619688
        ppois(2, 6)
#    b) 0.3637482
        dpois(1, 6/7)
#    c) 0.5756272
        1 - dpois(0, 6/7)

        
## 5 Uniform Distribution
        
# 1. a) 0
#    b) 0.5
#    c) 0.25
#    d) 0
# 2. a) Yes.
#    b) Yes.
#    c) No. Normal.
#    d) No. Unlikely to be uniform.
# 3. b/2
# 4. Average is 3.5; Average is 7. 