alpha <- 0.05
qnorm(1-alpha/2)

NSW <- read.csv("covid.19.ass2.csv")
head(NSW)
summary(NSW)
muhat_NSW <- mean(NSW$Recovery.Time)
varhat_NSW <- var(NSW$Recovery.Time)
n_NSW <- length(NSW$Recovery.Time)

qt(1-alpha/2, n_NSW-1)
muhat_NSW - qt(1-alpha/2, n_NSW-1) * sqrt(varhat_NSW) / sqrt(n_NSW)
muhat_NSW + qt(1-alpha/2, n_NSW-1) * sqrt(varhat_NSW) / sqrt(n_NSW)

israel <- read.csv("israeli.covid.19.ass2.csv")
head(israel)
summary(israel)
muhat_israel <- mean(israel$Recovery.Time)
varhat_israel <- var(israel$Recovery.Time)
n_israel <- length(israel$Recovery.Time)

muhat_israel - muhat_NSW
muhat_israel - muhat_NSW - qnorm(1-alpha/2) * sqrt(varhat_israel/n_israel + varhat_NSW/n_NSW)
muhat_israel - muhat_NSW + qnorm(1-alpha/2) * sqrt(varhat_israel/n_israel + varhat_NSW/n_NSW)

z_stat <- (muhat_israel - muhat_NSW) / sqrt(varhat_israel/n_israel + varhat_NSW/n_NSW)
2*pnorm(-abs(z_stat))
t.test(israel, NSW)$p.value


Erlang <- function(y, v, k) (y^(k-1))/factorial(k-1) * exp(-exp(-v)*y-k*v)
y_range <- seq(0,15,length.out=1000)
plot(y_range, Erlang(y_range, 0, 1), col='blue', type='l', xlab='y', ylab='P(Y=y)', main='Erlang pdfs')
lines(y_range, Erlang(y_range, 1, 1), col='red', type='l')
lines(y_range, Erlang(y_range, -1/2, 2), col='green', type='l')
legend(x = 10, y = 0.9, c("v=0, k=1", "v=1, k=1", "v=-1/2, k=2"), lty = c(1,1,1), col = c("blue", "red", "green"))


theta0 <- 0.9
n_x = 62
m_x = 53
theta_x <- m_x/n_x

theta_x - qnorm(0.975) * sqrt((theta_x * (1-theta_x))/n_x)
theta_x + qnorm(0.975) * sqrt((theta_x * (1-theta_x))/n_x)

z_x <- (theta_x - theta0) / sqrt(theta0 * (1-theta0) / n_x)
pnorm(z_x)
binom.test(m_x, n_x, theta0, alternative = "less")

n_y = 425
m_y = 399
theta_y <- m_y/n_y

theta_p <- (m_x + m_y) / (n_x + n_y)

z_stat <- (theta_x - theta_y) / sqrt(theta_p * (1-theta_p) * (1/n_x + 1/n_y))
2*pnorm(-abs(z_stat))
