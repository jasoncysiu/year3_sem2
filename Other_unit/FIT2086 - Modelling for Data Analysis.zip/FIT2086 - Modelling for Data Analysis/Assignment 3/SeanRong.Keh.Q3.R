####################################################################################
# Author: Sean Rong Keh
# Date: 14 Oct 2021
# Project: FIT2086 - Assignment 3
####################################################################################

# ----------------------------------------------------------------------------------

library(kknn)
library(boot)

ms.train <- read.csv("ms.train.2021.csv")
ms.test <- read.csv("ms.test.2021.csv")

# ----------------------------------------------------------------------------------
# Q 3.1

MSE <- numeric(25)

for (i in 1:25) {
  ytest.hat <- fitted(kknn(intensity ~ MZ, ms.train, ms.test, kernel = "gaussian", k = i))
  MSE[i] <- mean((ytest.hat - ms.test$intensity)^2)
}

plot(1:25, MSE, xlab = "k")

# ----------------------------------------------------------------------------------
# Q 3.2

ytest.hat <- fitted(kknn(intensity ~ MZ, ms.train, ms.test, kernel = "gaussian", k = 2))
plot(ms.train$MZ, ms.train$intensity, xlab = "MZ", ylab = "intensity", main = "k = 2")
lines(ms.test$MZ, ms.test$intensity, col = "red")
lines(ms.test$MZ, ytest.hat, col = "blue")
legend(x = 5000, y = 95, 
       c("Training Data", "True Spectrum", "Estimated Spectrum"), 
       lty = c(0,1,1), pch = c("o","",""), 
       col = c("black","red","blue"))

ytest.hat <- fitted(kknn(intensity ~ MZ, ms.train, ms.test, kernel = "gaussian", k = 6))
plot(ms.train$MZ, ms.train$intensity, xlab = "MZ", ylab = "intensity", main = "k = 6")
lines(ms.test$MZ, ms.test$intensity, col = "red")
lines(ms.test$MZ, ytest.hat, col = "blue")
legend(x = 5000, y = 95, 
       c("Training Data", "True Spectrum", "Estimated Spectrum"), 
       lty = c(0,1,1), pch = c("o","",""), 
       col = c("black","red","blue"))

ytest.hat <- fitted(kknn(intensity ~ MZ, ms.train, ms.test, kernel = "gaussian", k = 12))
plot(ms.train$MZ, ms.train$intensity, xlab = "MZ", ylab = "intensity", main = "k = 12")
lines(ms.test$MZ, ms.test$intensity, col = "red")
lines(ms.test$MZ, ytest.hat, col = "blue")
legend(x = 5000, y = 95, 
       c("Training Data", "True Spectrum", "Estimated Spectrum"), 
       lty = c(0,1,1), pch = c("o","",""), 
       col = c("black","red","blue"))

ytest.hat <- fitted(kknn(intensity ~ MZ, ms.train, ms.test, kernel = "gaussian", k = 25))
plot(ms.train$MZ, ms.train$intensity, xlab = "MZ", ylab = "intensity", main = "k = 25")
lines(ms.test$MZ, ms.test$intensity, col = "red")
lines(ms.test$MZ, ytest.hat, col = "blue")
legend(x = 5000, y = 95, 
       c("Training Data", "True Spectrum", "Estimated Spectrum"), 
       lty = c(0,1,1), pch = c("o","",""), 
       col = c("black","red","blue"))

# ----------------------------------------------------------------------------------
# Q 3.3

MSE[c(2, 6, 12, 25)]

# ----------------------------------------------------------------------------------
# Q 3.4

knn <- train.kknn(intensity ~ MZ, data = ms.train, kmax = 25, kernel = "gaussian")
knn$best.parameters$k

# ----------------------------------------------------------------------------------
# Q 3.5

ytest.hat <- fitted(kknn(intensity ~ MZ, ms.train, ms.test, kernel = "gaussian", 
                          k = knn$best.parameters$k))
sd(ytest.hat - ms.test$intensity)

# ----------------------------------------------------------------------------------
# Q 3.7

ytrain.hat <- fitted(kknn(intensity ~ MZ, ms.train, ms.train, kernel = "gaussian", 
                         k = knn$best.parameters$k))
ms.train[which.max(ytrain.hat),"MZ"]

# ----------------------------------------------------------------------------------
# Q 3.8

boot.prob = function(MZ, k, data, indices) {
  d = data[indices,]
  return(fitted(kknn(intensity ~ MZ, d, data.frame(MZ = MZ, intensity = 0), 
                     kernel = "gaussian", k = k)))
}

set.seed(2086)
bsbest <- boot(data = ms.train, statistic = boot.prob, R = 10000, MZ = 5792, 
           k = knn$best.parameters$k)

set.seed(2086)
bs3 <- boot(data = ms.train, statistic = boot.prob, R = 10000, MZ = 5792, 
           k = 3)

set.seed(2086)
bs20 <- boot(data = ms.train, statistic = boot.prob, R = 5000, MZ = 5792, 
           k = 20)

boot.ci(bsbest, conf = 0.95, type = "bca")
boot.ci(bs3, conf = 0.95, type = "bca")
boot.ci(bs20, conf = 0.95, type = "bca")
