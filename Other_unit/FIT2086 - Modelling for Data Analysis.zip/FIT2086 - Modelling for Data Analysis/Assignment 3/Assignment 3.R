setwd("~/Monash University/2021 Third Year/Semester 2/FIT2086 - Modelling for Data Analysis/Assignment 3")

rm(list=ls())

concrete <- read.csv("concrete.ass3.2021.csv")


### Question 1
# 1
fit <- lm(Strength ~ ., data = concrete)
summary(fit)

# 2
0.05/8

# 4
fit_bic <- step(fit, k = log(length(concrete$Strength)), trace = FALSE)
summary(fit_bic)

# 5

new_mix <- data.frame(Cement = 491, Blast.Furnace.Slag = 26, Fly.Ash = 123, Water = 210, Superplasticizer = 3.9, Coarse.Aggregate = 882, Fine.Aggregate = 669, Age = 28)
predict(fit_bic, new_mix, interval = "confidence", level = 0.95)
