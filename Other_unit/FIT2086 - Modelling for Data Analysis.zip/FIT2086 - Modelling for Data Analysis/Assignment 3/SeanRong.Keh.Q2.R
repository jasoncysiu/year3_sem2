####################################################################################
# Author: Sean Rong Keh
# Date: 14 Oct 2021
# Project: FIT2086 - Assignment 3
####################################################################################

# ----------------------------------------------------------------------------------

source("my.prediction.stats.R")
source("wrappers.R")
library(rpart)
library(boot)

par(xpd = NA)

heart.train <- read.csv("heart.train.ass3.2021.csv", stringsAsFactors = TRUE)
heart.test <- read.csv("heart.test.ass3.2021.csv", stringsAsFactors = TRUE)

# ----------------------------------------------------------------------------------
# Q 2.1

cv <- learn.tree.cv(HD ~ ., data=heart.train, nfolds = 10, m = 5000)
cv$best.tree

# ----------------------------------------------------------------------------------
# Q 2.2

plot(cv$best.tree)
text(cv$best.tree, pretty=12)

# ----------------------------------------------------------------------------------
# Q 2.3

cv$best.tree

# ----------------------------------------------------------------------------------
# Q 2.5

fullmod <- glm(HD ~ ., data = heart.train, family = binomial)
step.fit.bic <- step(fullmod, k = log(nrow(heart.train)), direction="both", trace = FALSE)
summary(step.fit.bic)

# ----------------------------------------------------------------------------------
# Q 2.7

my.pred.stats(predict(cv$best.tree, heart.test)[,"Y"], heart.test$HD)
my.pred.stats(predict(step.fit.bic,heart.test,type="response"), heart.test$HD)

# ----------------------------------------------------------------------------------
# Q 2.8
# (a)

temp <- predict(cv$best.tree, heart.test[62,])
temp[,'Y'] / temp[,'N']

# (b)

exp(predict(step.fit.bic, heart.test[62,]))

# ----------------------------------------------------------------------------------
# Q 2.9

set.seed(2086)
boot.prob = function(formula, data, indices) {
  d = data[indices,]
  fit = glm(formula, d, family = binomial)
  return(predict(fit, heart.test[65,], type = "response"))
}
bs65 <- boot(data = heart.train, statistic = boot.prob, R = 10000, 
             formula = HD ~ EXANG + OLDPEAK + CA + THAL)

set.seed(2086)
boot.prob = function(formula, data, indices) {
  d = data[indices,]
  fit = glm(formula, d, family = binomial)
  return(predict(fit, heart.test[66,], type = "response"))
}
bs66 <- boot(data = heart.train, statistic = boot.prob, R = 10000, 
             formula = HD ~ EXANG + OLDPEAK + CA + THAL)

boot.ci(bs65, conf = 0.95, type = "bca")
boot.ci(bs66, conf = 0.95, type = "bca")
