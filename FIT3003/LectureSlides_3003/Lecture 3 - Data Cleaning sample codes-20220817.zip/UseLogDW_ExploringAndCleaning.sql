-- Exploring and cleaning the data

--------------------------------------------------------------------------------
-- Is everything ok? It looks ok, doesn’t it?

-- Now, let’s look at the data more carefully. If you don’t look at the data, 
-- you will never know what has happened.

/*There are several questions that you need to ask yourself about the data:
1.	How many records in the operational database?
2.	How many records in the data warehouse?
3.	What kind of data is in the operational database?
4.	How do the tables look like in the data warehouse?*/

--------------------------------------------------------------------------------
-- Exploring the data
--------------------------------------------------------------------------------
SELECT * FROM dw.student; 
SELECT * FROM dw.uselog; 
SELECT * FROM dw.major; 
SELECT * FROM dw.class; 

SELECT count(*) FROM dw.major; 
SELECT count(*) FROM dw.class; 
SELECT count(*) FROM dw.student; 
SELECT count(*) FROM dw.uselog; 

-- This is how the tempfact_uselog was created:
CREATE TABLE tempfact_uselog AS
    SELECT u.log_date, u.log_time, u.student_id, s.class_id, s.major_code
    FROM dw.uselog u, dw.student s
    WHERE u.student_id = s.student_id;
    
-- Joining student and uselog tables
SELECT u.log_date, u.log_time, u.student_id, s.class_id, s.major_code
FROM dw.uselog u, dw.student s
WHERE u.student_id = s.student_id;

-- How many tuples are there in tempfact_uselog?
SELECT COUNT(*)
FROM (SELECT u.log_date, u.log_time, u.student_id, s.class_id, s.major_code
      FROM dw.uselog u, dw.student s
      WHERE u.student_id = s.student_id);    

-- How many tuples are there in uselog tempfact_uselog?
SELECT count(*) FROM dw.uselog; 
--------------------------------------------------------------------------------
-- Finding the errors:
--------------------------------------------------------------------------------
SELECT log_date, to_char(log_time, 'HH24:MI') AS log_time, student_id, act
FROM dw.uselog 
ORDER BY student_id;

SELECT student_id, COUNT(*) AS duplicate_Student_records
FROM dw.student
GROUP BY student_id
HAVING COUNT(*) > 1;

SELECT COUNT(*) FROM dw.student;

SELECT COUNT(*)
FROM (SELECT student_id, COUNT(*)
      FROM dw.student
      GROUP BY student_id
      HAVING COUNT(*) > 1);

-- check if there are illegal students in dw.uselog 
-- who are not in the student table
SELECT *
FROM dw.uselog
WHERE student_id NOT IN ( SELECT student_id FROM dw.student);

-- check if there are invalid majors in dw.student 
SELECT *
FROM dw.uselog, dw.student
WHERE dw.uselog.student_id = dw.student.student_id
AND dw.student.major_code NOT IN (SELECT major_code FROM dw.major);

-- check if there are invalid class in dw.student 
SELECT *
FROM dw.uselog, dw.student
WHERE dw.uselog.student_id = dw.student.student_id AND dw.student.class_id NOT IN
(SELECT class_id FROM dw.class);

-- check if there are records in uselog not in tempfact_uselog 
SELECT *
FROM dw.uselog
WHERE log_date NOT IN (SELECT log_date FROM tempfact_uselog) 
AND log_time NOT IN (SELECT log_time FROM tempfact_uselog) 
AND student_id NOT IN (SELECT student_id FROM tempfact_uselog);

-- check if there are duplicate records in the uselog 
SELECT to_char(log_time, 'HH24:MI') AS log_time, log_date, student_id, act, 
       count(*) AS duplicate_uselog_records
FROM dw.uselog
GROUP BY log_time, log_date, student_id, act 
HAVING count(*) > 1;

--------------------------------------------------------------------------------
-- Cleaning the data
--------------------------------------------------------------------------------
-- Error 1: Duplicate record in STUDENT table 
--(14288 out of 37951 records were duplicated)
--------------------------------------------------------------------------------
-- Detection Strategy:
SELECT student_id, COUNT(*)
FROM dw.student
GROUP BY student_id
HAVING COUNT(*) > 1;

SELECT COUNT(*) FROM dw.student;

SELECT COUNT(*)
FROM (SELECT student_id, COUNT(*)
      FROM dw.student
      GROUP BY student_id
      HAVING COUNT(*) > 1);

-- Solution:
SELECT COUNT(*)
FROM (SELECT distinct  u.log_date, u.log_time, u.student_id, s.class_id, s.major_code
      FROM dw.uselog u, dw.student s
      WHERE u.student_id = s.student_id);
-- 108261 rows  retuned
--------------------------------------------------------------------------------
-- Error 2: Duplicate record in USELOG table 
--(6 out of 108267 records were duplicated)
--------------------------------------------------------------------------------
-- Detection Strategy:
SELECT to_char(log_time, 'HH24:MI') AS log_time, log_date, student_id, act, 
       count(*) AS duplicate_uselog_records
FROM dw.uselog
GROUP BY log_time, log_date, student_id, act 
HAVING count(*) > 1;

-- Solution:   
-- Since tempfact_uselog2 which has 108261 records is in fact CORRECT, 
-- whereas dw.uselog having 108267 records is not accurate.   
