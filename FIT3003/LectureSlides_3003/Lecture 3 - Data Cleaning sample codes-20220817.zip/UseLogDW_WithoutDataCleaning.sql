-- What happens when data is not cleaned

--------------------------------------------------------------------------------
-- access the operational database
--------------------------------------------------------------------------------
Select * from dw.student; 
Select * from dw.uselog; 
Select * from dw.major; 
Select * from dw.class; 

--------------------------------------------------------------------------------
-- first create the dimensions
--------------------------------------------------------------------------------
DROP TABLE semesterdim;
--create semester dimension 
CREATE TABLE semesterdim (
    semid        VARCHAR2(10),
    sem_desc     VARCHAR2(20),
    begin_date   DATE,
    end_date     DATE
);
--------------------------------------------------------------------------------
DROP TABLE labtimedim;
-- create time dimension 
-- (note do not use time as a table name, it is a reserve keyword) 
CREATE TABLE labtimedim (
    timeid       NUMBER,
    time_desc    VARCHAR2(15),
    begin_time   DATE,
    end_time     DATE
);
--------------------------------------------------------------------------------
DROP TABLE majordim;
-- create major and class dimensions 
CREATE TABLE majordim AS
    SELECT * FROM dw.major;
--------------------------------------------------------------------------------
DROP TABLE classdim;
-- class dimensions 
CREATE TABLE classdim AS
    SELECT * FROM dw.class;
--------------------------------------------------------------------------------
-- populate dimensions created from scratch (i.e. semesterDIM and labtimeDIM)
--------------------------------------------------------------------------------
-- populate semester dimension
-- (the begin and end date can be changed)

INSERT INTO semesterDIM 
VALUES ('S1', 'Semester1', to_date('01-JAN', 'DD-MON'), to_date('15-JUL', 'DD-MON'));

INSERT INTO semesterDIM 
VALUES ('S2', 'Semester2', to_date('16-JUL', 'DD-MON'), to_date('31-DEC', 'DD-MON'));
--------------------------------------------------------------------------------
-- populate labtime dimension
INSERT INTO labtimeDIM 
VALUES (1, 'morning', to_date('06:01', 'HH24:MI'), to_date('12:00', 'HH24:MI'));

INSERT INTO labtimeDIM 
VALUES (2, 'afternoon', to_date('12:01', 'HH24:MI'), to_date('18:00', 'HH24:MI'));

INSERT INTO labtimeDIM 
VALUES (3, 'night', to_date('18:01', 'HH24:MI'), to_date('06:00', 'HH24:MI'));
--------------------------------------------------------------------------------
-- secondly, create a temp fact table to extract from uselog table 
--------------------------------------------------------------------------------
DROP TABLE tempfact_uselog;

CREATE TABLE tempfact_uselog AS
    SELECT u.log_date, u.log_time, u.student_id, s.class_id, s.major_code
    FROM dw.uselog u, dw.student s
    WHERE u.student_id = s.student_id;
--------------------------------------------------------------------------------
-- adding the labtime and semester to the temp fact table
--------------------------------------------------------------------------------
-- add a column in the tempfact table to store timeid
-- (cannot directly do this in the tempfact table because
-- log_time was of DATE type and timeid is of NUMBER type).

ALTER TABLE tempfact_uselog ADD ( timeid NUMBER );

-- populate the new attribute timeid by summarizing the date(log_time)

UPDATE tempfact_uselog
SET timeid = 1
WHERE to_char(log_time, 'HH24:MI') >= '06:01'
AND to_char(log_time, 'HH24:MI') <= '12:00';

UPDATE tempfact_uselog
SET timeid = 2
WHERE to_char(log_time, 'HH24:MI') >= '12:01'
AND to_char(log_time, 'HH24:MI') <= '18:00';

-- note that we use OR in the last update statement to
-- include the time between 18:01 and 06:00.
UPDATE tempfact_uselog
SET timeid = 3
WHERE to_char(log_time, 'HH24:MI') >= '18:01'
OR to_char(log_time, 'HH24:MI') <= '06:00';

-- alternatively, you may want to update timeid=3
-- for all other records where the time_id is still empty
UPDATE tempfact_uselog
SET timeid = 3
WHERE timeid IS NULL;
--------------------------------------------------------------------------------
-- add a column in the tempfact_uselog table to store semid
-- (cannot directly do this in the test table because
-- log_date was of DATE type and semid is of VARCHAR type.)

ALTER TABLE tempfact_uselog ADD (semid VARCHAR2(10));

-- populate the new attribute semid by summarizing the date(log_date)

UPDATE tempfact_uselog
SET semid = 'S1'
WHERE to_char(log_date, 'MMDD') >= '0101'
AND to_char(log_date, 'MMDD') <= '0715';

UPDATE tempfact_uselog
SET semid = 'S2'
WHERE to_char(log_date, 'MMDD') >= '0716'
AND to_char(log_date, 'MMDD') <= '1231';

--------------------------------------------------------------------------------
-- Now, create the fact table,
-- make sure to include the TOTAL aggregate.
--------------------------------------------------------------------------------
-- This is an aggregate table of the earlier tempfact table.
DROP TABLE fact_uselog;

CREATE TABLE fact_uselog AS
    SELECT t.semid, t.timeid, t.class_id, t.major_code,
           COUNT(t.student_id) AS total_usage
    FROM tempfact_uselog t
    GROUP BY t.semid, t.timeid, t.class_id, t.major_code;

--------------------------------------------------------------------------------
-- What the fact table looks like before data cleaning
--------------------------------------------------------------------------------    
SELECT * 
FROM fact_uselog 
ORDER BY total_usage desc;




