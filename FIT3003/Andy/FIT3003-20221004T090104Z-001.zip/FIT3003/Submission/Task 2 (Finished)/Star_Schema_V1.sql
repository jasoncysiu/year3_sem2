-- create time DIM
DROP TABLE TIMEDIM_v1 CASCADE CONSTRAINTS PURGE;
CREATE TABLE TIMEDIM_v1 AS
SELECT
    unique to_char(date_time, 'yyyyMM') as Time_Id,
    to_char(date_time, 'yyyy') as Year,
    to_char(date_time, 'MM') as Month,
    case
        when to_char(date_time,'MM') in ('12', '01', '02') then 'Summer'
        when to_char(date_time,'MM') in ('03', '04', '05') then 'Autumn'
        when to_char(date_time,'MM') in ('06', '07', '08') then 'Winter'
        when to_char(date_time,'MM') in ('09', '10', '11') then 'Spring'
    end as Season
FROM
    (SELECT * FROM
            (SELECT sale_date as date_time FROM sale)
            UNION
            (SELECT movie_release_date as date_time from movie));

SELECT * FROM TIMEDIM_v1 order by Year, Month;


-- create Runtime DIM
DROP TABLE RUNTIMEDIM_v1 CASCADE CONSTRAINTS PURGE;
CREATE TABLE RUNTIMEDIM_v1 (
    Runtime_Id NVARCHAR2(50),
    Runtime_Description NVARCHAR2(50),
    PRIMARY KEY(Runtime_Id)
);
INSERT INTO RUNTIMEDIM_v1 VALUES ('Short', 'Less than 50 minutes');
INSERT INTO RUNTIMEDIM_v1 VALUES ('Medium', 'Between 50 and 100 minutes');
INSERT INTO RUNTIMEDIM_v1 VALUES ('Long', 'Longer than 100 minutes');

SELECT * FROM RUNTIMEDIM_v1;


-- create Review DIM
DROP TABLE MOVIEREVIEWDIM_v1 CASCADE CONSTRAINTS PURGE;
CREATE TABLE MOVIEREVIEWDIM_v1 AS
SELECT
    unique REVIEW_SCORE as Review_Id,
    REVIEW_SCORE as Review_Score
FROM
    review;
INSERT INTO MOVIEREVIEWDIM_V1 VALUES (0, 0);
SELECT * FROM MOVIEREVIEWDIM_v1 ;


-- create Genre DIM
DROP TABLE GENREDIM_v1 CASCADE CONSTRAINTS PURGE;
CREATE TABLE GENREDIM_v1  AS
SELECT * FROM genre;

SELECT * FROM GENREDIM_v1;

-- create Company DIM
DROP TABLE PRODUCTIONCOMPANYDIM_v1 CASCADE CONSTRAINTS PURGE;
CREATE TABLE PRODUCTIONCOMPANYDIM_v1  AS
SELECT * FROM production_company;

SELECT * FROM PRODUCTIONCOMPANYDIM_v1;


-- create movie genre BRIDGE
DROP TABLE MOVIEGENREBRIDGE_v1 CASCADE CONSTRAINTS PURGE;
CREATE TABLE MOVIEGENREBRIDGE_v1  AS
SELECT * FROM movie_genre;

SELECT * FROM MOVIEGENREBRIDGE_v1;


-- create movie company BRIDGE
DROP TABLE MOVIECOMPANYBRIDGE_v1 CASCADE CONSTRAINTS PURGE;
CREATE TABLE MOVIECOMPANYBRIDGE_v1  AS
SELECT * FROM movie_company;

SELECT * FROM MOVIECOMPANYBRIDGE_v1;


-- create Movie DIM
DROP TABLE MOVIEDIM_v1 CASCADE CONSTRAINTS PURGE;

CREATE TABLE MOVIEDIM_v1  AS
SELECT
    m.Movie_Id,
    1.0 / (SELECT Count(*)
            FROM movie m2, movie_company mc2
            WHERE m2.Movie_Id = mc2.Movie_Id
            AND m2.Movie_Id = m.Movie_Id
            GROUP BY m2.Movie_Id) as Company_Weight_Factor,
    1.0 / (SELECT Count(*)
            FROM movie m2, movie_genre mg2
            WHERE m2.Movie_Id = mg2.Movie_Id
            AND m2.Movie_Id = m.Movie_Id
            GROUP BY m2.Movie_Id) as Genre_Weight_Factor,
    LISTAGG(unique mc.Company_Id, '_') WITHIN GROUP (ORDER BY mc.Company_Id) as Company_Aggregate_List,
    LISTAGG(unique mg.Genre_Id, '_') WITHIN GROUP (ORDER BY mg.Genre_Id) as Genre_Aggregate_List
FROM
    movie m,
    movie_company mc,
    movie_genre mg
WHERE
    m.Movie_Id = mc.Movie_Id AND
    m.Movie_Id = mg.Movie_Id
GROUP BY
    m.Movie_ID;

SELECT * FROM MOVIEDIM_v1;



-- create Movie FACT
DROP TABLE MOVIETEMPFACT CASCADE CONSTRAINTS PURGE;
CREATE TABLE MOVIETEMPFACT AS
SELECT
    to_char(Movie_Release_Date, 'yyyyMM') as Time_Id,
    m.Movie_Runtime,
    m.Movie_Id,
    Round(AVG(NVL(r.Review_Score, 0))) as Review_Id
FROM
    movie m
LEFT OUTER JOIN
    review r ON m.Movie_Id = r.Movie_Id
GROUP BY
    m.Movie_Id,
    m.Movie_Runtime,
    m.Movie_Release_Date;

ALTER TABLE MOVIETEMPFACT ADD ( Runtime_Id NVARCHAR2(50));
UPDATE MOVIETEMPFACT
SET Runtime_Id =
    case
        when Movie_Runtime < 50 then 'Short'
        when Movie_Runtime >= 50 and Movie_Runtime <= 100 then 'Medium'
        when Movie_Runtime > 100 then 'Long'
    end;

SELECT * FROM MOVIETEMPFACT;

DROP TABLE MOVIEFACT_v1 CASCADE CONSTRAINTS PURGE;
CREATE TABLE MOVIEFACT_v1 AS
SELECT
    Time_Id,
    Review_Id,
    Runtime_Id,
    Count(*) as Total_Num_Movies
FROM
    MOVIETEMPFACT
GROUP BY
    Time_Id,
    Review_Id,
    Runtime_Id;

SELECT * FROM MOVIEFACT_v1;


-- create booking mode DIM
DROP TABLE BOOKINGMODEDIM_v1 CASCADE CONSTRAINTS PURGE;
CREATE TABLE BOOKINGMODEDIM_v1 AS
SELECT * FROM booking_mode;

SELECT * FROM BOOKINGMODEDIM_v1;

-- create customer age DIM
DROP TABLE CUSTOMERAGEDIM_v1 CASCADE CONSTRAINTS PURGE;
CREATE TABLE CUSTOMERAGEDIM_v1 (
	Age_Id NVARCHAR2(50),
	Age_Description NVARCHAR2(50),
	PRIMARY KEY(Age_Id)
);
INSERT INTO CUSTOMERAGEDIM_v1 VALUES ('Child', '0-16 years old');
INSERT INTO CUSTOMERAGEDIM_v1 VALUES ('Young Adults', '17-30 years old');
INSERT INTO CUSTOMERAGEDIM_v1 VALUES ('Middle-aged adults', '31-45 years old');
INSERT INTO CUSTOMERAGEDIM_v1 VALUES ('Old-aged adults', 'Over 45 years old');

SELECT * FROM CUSTOMERAGEDIM_v1;


-- create cinema rating DIM
DROP TABLE CINEMARATINGDIM_v1 CASCADE CONSTRAINTS PURGE;
CREATE TABLE CINEMARATINGDIM_v1 AS
SELECT
	UNIQUE RATING_SCORE as Rating_Id,
	RATING_SCORE as Rating_Score
FROM
	CINEMA_RATING;
INSERT INTO CINEMARATINGDIM_V1 VALUES (0, 0);

SELECT * FROM CINEMARATINGDIM_v1;


-- create cinema location DIM
DROP TABLE CINEMALOCATIONDIM_v1 CASCADE CONSTRAINTS PURGE;
CREATE TABLE CINEMALOCATIONDIM_v1 AS
SELECT DISTINCT CINEMA_SUBURB AS
	Suburb_Id,
	Cinema_Suburb,
    Cinema_State
FROM
	CINEMA;
SELECT * FROM CINEMALOCATIONDIM_v1;

-- create Cinema FACT
DROP TABLE CINEMATEMPFACT CASCADE CONSTRAINTS PURGE;
CREATE TABLE CINEMATEMPFACT AS
SELECT
	c.Cinema_Suburb as Suburb_Id,
	Round(AVG(NVL(cr.RATING_SCORE, 0))) as Rating_Id,
	count(c.CINEMA_Id) as Total_Num_Cinema
FROM
	cinema c
LEFT OUTER JOIN	cinema_rating cr ON	c.Cinema_Id = cr.Cinema_Id
GROUP BY
	c.CINEMA_SUBURB;

DROP TABLE CINEMAFACT_v1 CASCADE CONSTRAINTS PURGE;
CREATE TABLE CINEMAFACT_v1 AS
SELECT
	Suburb_Id,
	Rating_Id,
	sum(Total_Num_Cinema) as Total_Num_Cinema
FROM
	CINEMATEMPFACT
GROUP BY
	Suburb_Id,
	Rating_Id;

SELECT * FROM CINEMAFACT_v1 order by Suburb_Id;


 -- create Sale FACT
DROP TABLE SALETEMPFACT CASCADE CONSTRAINTS PURGE;
CREATE TABLE SALETEMPFACT AS
SELECT
	c.CINEMA_SUBURB AS Suburb_Id,
	bm.mode_id,
    case
		when Round(((sysdate - cu.cust_dob)/365.4)) >= 0 and Round(((sysdate - cu.cust_dob)/365.4)) <= 16 then 'Child'
		when Round(((sysdate - cu.cust_dob)/365.4)) >= 17 and Round(((sysdate - cu.cust_dob)/365.4)) <= 30 then 'Young adults'
		when Round(((sysdate - cu.cust_dob)/365.4)) >= 31 and Round(((sysdate - cu.cust_dob)/365.4)) <= 45 then 'Middle-aged adults'
		when Round(((sysdate - cu.cust_dob)/365.4)) > 45 then 'Old-aged adults'
	end as Age_Id,
	case
        when m.Movie_Runtime < 50 then 'Short'
        when m.Movie_Runtime >= 50 and Movie_Runtime <= 100 then 'Medium'
        when m.Movie_Runtime > 100 then 'Long'
    end as Runtime_Id,
	to_char(s.SALE_DATE, 'yyyyMM') AS time_id,
	s.Sale_Number_Of_Tickets,
    s.sale_total_price,
    s.Movie_Id,
    ROUND(AVG(cr.rating_score)) as rating_Id,
    ROUND(AVG(mr.review_Score)) as Review_Id
FROM
	movie m,
	sale  s,
	booking_mode bm,
	cinema c,
	customer cu,
    review mr,
    cinema_rating cr
WHERE
	m.movie_id = s.movie_id
	AND s.mode_id = bm.mode_id
 	AND c.cinema_id = s.cinema_id
	AND cu.cust_id = s.cust_id
    AND cr.cinema_Id = s.cinema_Id
    AND s.movie_Id = mr.Movie_Id
GROUP BY
    c.CINEMA_SUBURB,
    bm.mode_id,
    cu.cust_dob,
    m.Movie_Runtime,
    to_char(s.SALE_DATE, 'yyyyMM'),
    s.Sale_Number_Of_Tickets,
    s.sale_total_price,
    s.Movie_Id;


DROP TABLE SALESFACT_v1 CASCADE CONSTRAINTS PURGE;
CREATE TABLE SALESFACT_v1 AS
SELECT
	st.Suburb_Id,
	st.Rating_Id,
	st.Mode_Id,
	st.Age_Id,
    st.Time_Id,
	st.Runtime_Id,
    st.Movie_Id,
    st.Review_Id,
	sum(sale_number_of_tickets) as Total_Num_Tickets_Sold,
	sum(sale_total_price) as Total_Sales
FROM
	SALETEMPFACT st
GROUP BY
	st.Suburb_Id,
	st.Rating_Id,
	st.Mode_Id,
	st.Age_Id,
    	st.Time_Id,
	st.Runtime_Id,
   	st.Movie_Id,
  	st.Review_Id;

SELECT * FROM SALESFACT_v1;





