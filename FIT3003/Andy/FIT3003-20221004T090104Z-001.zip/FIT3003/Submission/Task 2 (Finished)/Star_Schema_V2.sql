
-- create cinema DIM
DROP TABLE CINEMADIM_v2 CASCADE CONSTRAINTS PURGE;
CREATE TABLE CINEMADIM_v2 AS
SELECT * FROM Cinema;

SELECT * FROM CINEMADIM_v2;

-- create cinema rating DIM
DROP TABLE CINEMARATINGDIM_v2 CASCADE CONSTRAINTS PURGE;
CREATE TABLE CINEMARATINGDIM_v2 AS
SELECT * FROM Cinema_Rating;

SELECT * FROM CINEMARATINGDIM_v2;

-- create customer DIM
DROP TABLE CUSTOMERDIM_v2 CASCADE CONSTRAINTS PURGE;
CREATE TABLE CUSTOMERDIM_v2 AS
SELECT
	Cust_Id,
	Cust_DOB
FROM
    Customer;

SELECT * FROM CUSTOMERDIM_v2;

-- create sale DIM
DROP TABLE SALESDIM_v2 CASCADE CONSTRAINTS PURGE;
CREATE TABLE SALESDIM_v2 AS
SELECT
    Sale_Id,
    Sale_Date,
   case
        when to_char(Sale_Date,'MM') in ('12', '01', '02') then 'Summer'
        when to_char(Sale_Date,'MM') in ('03', '04', '05') then 'Autumn'
        when to_char(Sale_Date,'MM') in ('06', '07', '08') then 'Winter'
        when to_char(Sale_Date,'MM') in ('09', '10', '11') then 'Spring'
    end as Season
FROM
    Sale;

SELECT * FROM SALESDIM_v2;


-- create movie DIM
DROP TABLE MOVIEDIM_v2 CASCADE CONSTRAINTS PURGE;
CREATE TABLE MOVIEDIM_v2 AS
SELECT
	m.Movie_Id,
	m.Movie_Name,
	m.Movie_Release_Date,
    m.Movie_Runtime,
    1.0 / (SELECT Count(*)
        FROM movie m2, movie_company mc2
        WHERE m2.Movie_Id = mc2.Movie_Id
        AND m2.Movie_Id = m.Movie_Id
        GROUP BY m2.Movie_Id) as Company_Weight_Factor,
    1.0 / (SELECT Count(*)
        FROM movie m2, movie_genre mg2
        WHERE m2.Movie_Id = mg2.Movie_Id
        AND m2.Movie_Id = m.Movie_Id
        GROUP BY m2.Movie_Id) as Genre_Weight_Factor,
    LISTAGG(unique mc.Company_Id, '_') WITHIN GROUP (ORDER BY mc.Company_Id) as Company_Aggregate_List,
    LISTAGG(unique mg.Genre_Id, '_') WITHIN GROUP (ORDER BY mg.Genre_Id) as Genre_Aggregate_List
FROM
    movie m,
    movie_company mc,
    movie_genre mg
WHERE
    m.Movie_Id = mc.Movie_Id AND
    m.Movie_Id = mg.Movie_Id
GROUP BY
    m.Movie_Id,
	m.Movie_Name,
	m.Movie_Release_Date,
    m.Movie_Runtime;


SELECT * FROM MOVIEDIM_v2;


-- create review DIM
DROP TABLE REVIEWDIM_v2 CASCADE CONSTRAINTS PURGE;
CREATE TABLE REVIEWDIM_v2 AS
SELECT * FROM Review;

SELECT * FROM REVIEWDIM_v2;


-- create cinema FACT
DROP TABLE CINEMAFACT_v2 CASCADE CONSTRAINTS PURGE;
CREATE TABLE CINEMAFACT_v2 AS
SELECT
	Cinema_Id,
    Count(*) as Total_Num_Cinema
FROM
	Cinema
GROUP BY
    Cinema_Id;

SELECT * FROM CINEMAFACT_v2 ;

-- create movie FACT
DROP TABLE MOVIEFACT_v2 CASCADE CONSTRAINTS PURGE;
CREATE TABLE MOVIEFACT_v2 AS
SELECT
    Movie_id,
    count(*) as Total_Num_Movies
FROM
	Movie
GROUP BY
    Movie_Id;

SELECT * FROM MOVIEFACT_v2;


-- create sale FACT
DROP TABLE SALESFACT_v2 CASCADE CONSTRAINTS PURGE;
CREATE TABLE SALESFACT_v2 AS
SELECT Sale_Id,
       Movie_Id,
       Cinema_Id,
       Mode_Id,
       Cust_Id,
       SALE_NUMBER_OF_TICKETS as Total_Num_Tickets,
       Sale_Total_Price       as Total_Sales
FROM Sale;


SELECT * FROM SALESFACT_v2;















