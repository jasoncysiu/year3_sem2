-- 3a) Report 2 - Top n% - level 2
SELECT
    *
FROM
    (SELECT
        g.genre_description AS genre,
        SUM(s.total_sales) AS Total_Sales,  
        PERCENT_RANK () OVER(ORDER BY SUM(s.total_sales)) AS PERCENT_RANK
FROM
    SALESFACT_V1 s,
    MOVIEDIM_V1 m,
    MOVIEGENREBRIDGE_V1 mg,
    GENREDIM_V1 g,
    TIMEDIM_V1 t
WHERE
        s.time_id = t.time_id
    AND s.movie_id = m.movie_id
    AND mg.movie_id = s.movie_id
    AND mg.genre_id = g.genre_id
    AND t.year >= 2020
group by 
    g.genre_description)
WHERE 
    PERCENT_RANK >= 0.8;

-- 3a) Report 2 - Top n% - level 0
SELECT
    *
FROM
    (SELECT
        g.genre_description AS genre,
        SUM(s.total_sales) AS Total_Sales,  
        PERCENT_RANK () OVER(ORDER BY SUM(s.total_sales)) AS PERCENT_RANK
FROM
    SALESFACT_V2 s,
        SALESDIM_V2 sd,
        GENREDIM_V1 g,
        MOVIEGENREBRIDGE_V1 mg,
        MOVIEDIM_V2 m
    WHERE
        s.SALE_ID = sd.SALE_ID
        AND s.Movie_Id = m.Movie_Id
        AND mg.Movie_Id = s.Movie_Id
        AND mg.Genre_Id = g.Genre_id
        AND to_char(sd.SALE_DATE, 'yyyy') >= 2000
group by 
    g.genre_description)
WHERE 
    PERCENT_RANK >= 0.8;


-- 3a) Report 5 - level 2
SELECT
    DECODE(GROUPING(t.Season), 1, 'All Seasons', t.Season) as Season,
    DECODE(GROUPING(l.Suburb_Id), 1, 'All Locations', l.Suburb_Id) as Location,
    DECODE(GROUPING(r.Runtime_Description), 1, 'All Runtimes', r.Runtime_Description) as RunTime,
    SUM(s.Total_Sales) as Total_Sales
FROM
    SALESFACT_V1 s,
    TIMEDIM_V1 t,
    CINEMALOCATIONDIM_V1 l,
    RUNTIMEDIM_V1 r
WHERE
    s.Time_Id = t.Time_Id
    AND s.Suburb_Id = l.Suburb_Id
    AND s.Runtime_Id = r.Runtime_Id
GROUP BY
    CUBE(l.Suburb_Id, r.Runtime_Description), t.Season;


-- 3a) Report 5 - level 0
    SELECT
    DECODE(GROUPING(sd.Season), 1, 'All Seasons', sd.Season) as Season,
    DECODE(GROUPING(cd.CINEMA_ADDRESS), 1, 'All Locations', cd.CINEMA_ADDRESS) as Location,
    DECODE(GROUPING(md.MOVIE_RUNTIME), 1, 'All Runtimes', md.MOVIE_RUNTIME) as RunTime,
    SUM(s.Total_Sales) as Total_Sales
FROM
    SALESFACT_V2 s,
    SALESDIM_V2 sd,
    MOVIEDIM_V2 md,
    CINEMADIM_V2 cd
WHERE
    s.SALE_ID = sd.SALE_ID
    AND s.MOVIE_ID = md.MOVIE_ID
    AND s.CINEMA_ID = cd.CINEMA_ID
GROUP BY
    CUBE(cd.CINEMA_ADDRESS, md.MOVIE_RUNTIME), sd.Season;


--3c) Report 9 - level 2
SELECT
    t.year,
    t.month,
    SUM(s.total_sales) AS total_sales,
    AVG(SUM(s.total_sales))OVER(ORDER BY t.month ROWS 2 PRECEDING) AS MOVING_3_MONTH_AVG
FROM
    salesfact_v2 s,
    timedim_v2 t
WHERE
    s.time_id = t.time_id
    AND t.year = 2020
GROUP BY
    t.year,
    t.month
ORDER BY
    t.year;

--3c) Report 9 - level 0
SELECT
    to_char(sd.sale_date, 'YYYY') as sale_year,
    to_char(sd.sale_date, 'MM') as sale_month,
    SUM(s.total_sales) AS total_sales,
    AVG(SUM(s.total_sales))OVER(ORDER BY to_char(sd.sale_date, 'MM') ROWS 2 PRECEDING) AS MOVING_3_MONTH_AVG
FROM
    salesfact_v2 s,
    salesdim_v2 sd,
    moviedim_v2 md
WHERE
    s.sale_id = sd.sale_id
    AND s.movie_id = md.movie_id
    AND to_char(sd.sale_date, 'YYYY') = 2020
GROUP BY
    to_char(sd.sale_date, 'YYYY'),
    to_char(sd.sale_date, 'MM')
ORDER BY
    to_char(sd.sale_date, 'YYYY');