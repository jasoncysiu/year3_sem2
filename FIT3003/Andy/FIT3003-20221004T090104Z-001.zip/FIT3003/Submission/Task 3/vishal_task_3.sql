-- 3a) REPORT 3 - show all - level 2
SELECT
    genre_description,
    sum(total_sales) as total_sales
FROM salesfact_v1
NATURAL JOIN moviedim_v1
NATURAL JOIN moviegenrebridge_v1
NATURAL JOIN genredim_v1
NATURAL JOIN timedim_v1
WHERE year in (2020)
GROUP BY genre_description
ORDER BY genre_description;


-- 3a) REPORT 3 - show all - level 0
SELECT 
    genre_description, 
    sum(total_sales) as total_sales
FROM salesfact_v2
NATURAL JOIN salesdim_v2
NATURAL JOIN moviedim_v2
NATURAL JOIN moviegenrebridge_v2
NATURAL JOIN genredim_v2
WHERE to_char(sale_date, 'YYYY') IN (2020)
GROUP BY genre_description
ORDER BY genre_description;


-- 3b) REPORT 6 - level 2
SELECT 
    DECODE(GROUPING(mode_description), 1, 'Online', mode_description) as mode_description, 
    DECODE(GROUPING(year), 1, 'All years', year) as year, 
    DECODE(GROUPING(suburb_id), 1, 'All suburbs', suburb_id) as suburb, 
    count(*) as bookings
FROM salesfact_v1
NATURAL JOIN bookingmodedim_v1
NATURAL JOIN cinemalocationdim_v1
NATURAL JOIN timedim_v1
WHERE year IN (2020, 2021)
AND lower(mode_description) IN ('mobile app', 'website')
GROUP BY ROLLUP (mode_description, year, suburb_id);


-- 3b) REPORT 6 - level 0
SELECT 
    DECODE(GROUPING(mode_description), 1, 'Online', mode_description) as mode_description,
    DECODE(GROUPING(to_char(sale_date, 'YYYY')), 1, 'All years', to_char(sale_date, 'YYYY')) as year, 
    DECODE(GROUPING(cinema_suburb), 1, 'All suburbs', cinema_suburb) as suburb,
    count(*) as bookings
FROM salesfact_v2
NATURAL JOIN bookingmodedim_v2
NATURAL JOIN cinemadim_v2
NATURAL JOIN salesdim_v2
WHERE to_char(sale_date, 'YYYY') IN (2020, 2021)
AND lower(mode_description) IN ('mobile app', 'website')
GROUP BY ROLLUP(mode_description, to_char(sale_date, 'YYYY'), cinema_suburb);


-- 3b) REPORT 7 - level 2
SELECT 
    DECODE(GROUPING(year), 1, 'All years', year) as year,
    DECODE(GROUPING(cinema_suburb), 1, 'All Suburbs', cinema_suburb) as suburb,
    DECODE(GROUPING(season), 1, 'All seasons', season) as season,
    sum(total_sales) as total_sales
FROM salesfact_v1
NATURAL JOIN timedim_v1
NATURAL JOIN cinemalocationdim_v1
WHERE year IN (2019, 2020)
GROUP BY year, ROLLUP(cinema_suburb, season);


-- 3b) REPORT 7 - level 0
SELECT
    DECODE(GROUPING(to_char(sale_date, 'YYYY')), 1, 'All years', to_char(sale_date, 'YYYY')) as year,
    DECODE(GROUPING(cinema_suburb), 1, 'All Suburbs', cinema_suburb) as suburb,
    DECODE(GROUPING(season), 1, 'All seasons', season) as season,
    sum(total_sales) as total_sales
FROM salesfact_v2
NATURAL JOIN salesdim_v2
NATURAL JOIN cinemadim_v2
WHERE to_char(sale_date, 'YYYY') in (2019, 2020)
GROUP BY to_char(sale_date, 'YYYY'), ROLLUP(cinema_suburb, season);


-- 3c) REPORT 10 - level 2
SELECT 
    t.year,
    t.season,
    SUM(s.total_sales) as total_sales,
    SUM(SUM(s.total_sales)) OVER (ORDER BY t.season ROWS UNBOUNDED PRECEDING) as cumulative_sales
FROM salesfact_v1 s
NATURAL JOIN timedim_v1 t
WHERE lower(s.runtime_id) NOT IN ('short')
GROUP BY t.year, t.season
ORDER BY t.year;


-- 3c) REPORT 10 - level 0
SELECT
    to_char(sd.sale_date, 'YYYY') as sale_year,
    sd.season, 
    SUM(s.total_sales) as total_sales,
    SUM(SUM(s.total_sales)) OVER (ORDER BY sd.season ROWS UNBOUNDED PRECEDING) as cumulative_sales
FROM salesfact_v2 s
NATURAL JOIN salesdim_v2 sd
NATURAL JOIN moviedim_v2 md
WHERE md.movie_runtime > 50
GROUP BY to_char(sd.sale_date, 'YYYY'), sd.season
ORDER BY to_char(sd.sale_date, 'YYYY');