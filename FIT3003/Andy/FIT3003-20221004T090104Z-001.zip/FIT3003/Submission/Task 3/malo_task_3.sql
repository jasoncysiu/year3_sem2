-- 3a)  top n - level 2
SELECT
    *
FROM
    (SELECT
        g.Genre_Description as Genre,
        t.Season,
        RANK() OVER (PARTITION BY t.Season
            ORDER BY Round(SUM(s.Total_Sales * m.Genre_Weight_Factor),2) DESC) as rank,
        Round(SUM(s.Total_Sales * m.Genre_Weight_Factor),2) as Total_Sales
    FROM
        SALESFACT_V1 s,
        TIMEDIM_V1 t,
        GENREDIM_V1 g,
        MOVIEGENREBRIDGE_V1 mg,
        MOVIEDIM_V1 m
    WHERE
        s.Time_Id = t.Time_Id
        AND s.Movie_Id = m.Movie_Id
        AND mg.Movie_Id = s.Movie_Id
        AND mg.Genre_Id = g.Genre_id
        AND t.Year >= 2000
    GROUP BY
        g.Genre_Description,
        t.Season
    ORDER BY
        t.Season)
WHERE
    rank <=3;


-- 3a)  top n - level 0
SELECT
    *
FROM
    (SELECT
        g.Genre_Description as Genre,
        sd.Season,
        RANK() OVER (PARTITION BY sd.Season
            ORDER BY Round(SUM(s.Total_Sales * m.Genre_Weight_Factor),2) DESC) as rank,
        Round(SUM(s.Total_Sales * m.Genre_Weight_Factor),2) as Total_Sales

    FROM
        SALESFACT_V2 s,
        SALESDIM_V2 sd,
        GENREDIM_V2 g,
        MOVIEGENREBRIDGE_V1 mg,
        MOVIEDIM_V2 m
    WHERE
        s.SALE_ID = sd.SALE_ID
        AND s.Movie_Id = m.Movie_Id
        AND mg.Movie_Id = s.Movie_Id
        AND mg.Genre_Id = g.Genre_id
        AND to_char(sd.SALE_DATE, 'yyyy') >= 2000
    GROUP BY
            g.Genre_Description,
            sd.Season
        ORDER BY
            sd.Season)
WHERE
    rank <=3;



-- 3b) REPORT 4 - level 2
SELECT
    DECODE(GROUPING(t.Season), 1, 'All Seasons', t.Season) as Season,
    DECODE(GROUPING(l.Suburb_Id), 1, 'All Locations', l.Suburb_Id) as Location,
    DECODE(GROUPING(r.Runtime_Description), 1, 'All Runtimes', r.Runtime_Description) as RunTime,
    SUM(s.Total_Sales) as Total_Sales
FROM
    SALESFACT_V1 s,
    TIMEDIM_V1 t,
    CINEMALOCATIONDIM_V1 l,
    RUNTIMEDIM_V1 r
WHERE
    s.Time_Id = t.Time_Id
    AND s.Suburb_Id = l.Suburb_Id
    AND s.Runtime_Id = r.Runtime_Id
GROUP BY
    CUBE(t.Season, l.Suburb_Id, r.Runtime_Description);


-- 3b) REPORT 4 - level 0
SELECT
    DECODE(GROUPING(sd.Season), 1, 'All Seasons', sd.Season) as Season,
    DECODE(GROUPING(cd.CINEMA_ADDRESS), 1, 'All Locations', cd.CINEMA_ADDRESS) as Location,
    DECODE(GROUPING(md.MOVIE_RUNTIME), 1, 'All Runtimes', md.MOVIE_RUNTIME) as RunTime,
    SUM(s.Total_Sales) as Total_Sales
FROM
    SALESFACT_V2 s,
    SALESDIM_V2 sd,
    MOVIEDIM_V2 md,
    CINEMADIM_V2 cd
WHERE
    s.SALE_ID = sd.SALE_ID
    AND s.MOVIE_ID = md.MOVIE_ID
    AND s.CINEMA_ID = cd.CINEMA_ID
GROUP BY
    CUBE(sd.Season, cd.CINEMA_ADDRESS, md.MOVIE_RUNTIME);



-- 3c) REPORT 8 - level 2
SELECT
    t.Year,
    Round(SUM(s.Total_Sales * m.Genre_Weight_Factor),2) as Total_Sales,
    SUM(Round(SUM(s.Total_Sales * m.Genre_Weight_Factor),2))
        OVER (ORDER BY t.Year ROWS UNBOUNDED PRECEDING) as Cumulative_Sales
    FROM
        SALESFACT_V1 s,
        TIMEDIM_V1 t,
        GENREDIM_V1 g,
        MOVIEGENREBRIDGE_V1 mg,
        MOVIEDIM_V1 m
    WHERE
        s.Time_Id = t.Time_Id
        AND s.Movie_Id = m.Movie_Id
        AND mg.Movie_Id = s.Movie_Id
        AND mg.Genre_Id = g.Genre_id
        AND g.Genre_Description = 'Animation'
    GROUP BY
        t.Year
    ORDER BY
        t.Year;


-- 3c) REPORT 8 - level 0
SELECT
    to_char(sd.SALE_DATE, 'yyyy') as Year,
    Round(SUM(s.Total_Sales * m.Genre_Weight_Factor),2) as Total_Sales,
    SUM(Round(SUM(s.Total_Sales * m.Genre_Weight_Factor),2))
        OVER (ORDER BY to_char(sd.SALE_DATE, 'yyyy') ROWS UNBOUNDED PRECEDING) as Cumulative_Sales
    FROM
        SALESFACT_V2 s,
        SALESDIM_V2 sd,
        GENREDIM_V1 g,
        MOVIEGENREBRIDGE_V1 mg,
        MOVIEDIM_V2 m
    WHERE
        s.SALE_ID = sd.SALE_ID
        AND s.Movie_Id = m.Movie_Id
        AND mg.Movie_Id = s.Movie_Id
        AND mg.Genre_Id = g.Genre_id
        AND g.Genre_Description = 'Animation'
    GROUP BY
        to_char(sd.SALE_DATE, 'yyyy')
    ORDER BY
        to_char(sd.SALE_DATE, 'yyyy');


-- 3d) REPORT 11 - level 2
SELECT
    *
FROM
    (SELECT
        g.Genre_Description as Genre,
        b.Mode_Description,
        t.Month,
        RANK() OVER (PARTITION BY g.Genre_Description
            ORDER BY Round(SUM(s.Total_Sales * m.Genre_Weight_Factor),2) DESC) as  Genre_Rank,
        RANK() OVER (PARTITION BY  b.Mode_Description
            ORDER BY Round(SUM(s.Total_Sales * m.Genre_Weight_Factor),2) DESC) as Mode_Rank,
        Round(SUM(s.Total_Sales * m.Genre_Weight_Factor),2) as Total_Sales
    FROM
        SALESFACT_V1 s,
        TIMEDIM_V1 t,
        GENREDIM_V1 g,
        MOVIEGENREBRIDGE_V1 mg,
        MOVIEDIM_V1 m,
        BOOKINGMODEDIM_V1 b
    WHERE
        s.Time_Id = t.Time_Id
        AND s.Movie_Id = m.Movie_Id
        AND mg.Movie_Id = s.Movie_Id
        AND mg.Genre_Id = g.Genre_id
        AND s.Mode_Id = b.Mode_Id
    GROUP BY
        g.Genre_Description,
        b.Mode_Description,
        t.Month
    ORDER BY
        g.Genre_Description,
        t.Month)
ORDER BY
    Genre_Rank,
    Mode_Rank;


-- 3d) REPORT 11 - level 0
SELECT
    *
FROM
    (SELECT
        g.Genre_Description as Genre,
        b.Mode_Description,
        to_char(sd.SALE_DATE, 'MM') as Month,
        RANK() OVER (PARTITION BY g.Genre_Description
            ORDER BY Round(SUM(s.Total_Sales * m.Genre_Weight_Factor),2) DESC) as  Genre_Rank,
        RANK() OVER (PARTITION BY  b.Mode_Description
            ORDER BY Round(SUM(s.Total_Sales * m.Genre_Weight_Factor),2) DESC) as Mode_Rank,
        Round(SUM(s.Total_Sales * m.Genre_Weight_Factor),2) as Total_Sales
    FROM
        SALESFACT_V2 s,
        SALESDIM_V2 sd,
        GENREDIM_V1 g,
        MOVIEGENREBRIDGE_V1 mg,
        MOVIEDIM_V2 m,
        BOOKINGMODEDIM_V1 b
    WHERE
        s.SALE_ID = sd.SALE_ID
        AND s.Movie_Id = m.Movie_Id
        AND mg.Movie_Id = s.Movie_Id
        AND mg.Genre_Id = g.Genre_id
        AND s.Mode_Id = b.Mode_Id
    GROUP BY
        g.Genre_Description,
        b.Mode_Description,
        to_char(sd.SALE_DATE, 'MM')
    ORDER BY
        g.Genre_Description,
        to_char(sd.SALE_DATE, 'MM'))
ORDER BY
    Genre_Rank,
    Mode_Rank;