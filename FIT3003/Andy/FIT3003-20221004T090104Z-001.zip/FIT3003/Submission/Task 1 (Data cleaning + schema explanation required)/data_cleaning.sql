DROP TABLE customer;
CREATE TABLE customer
AS SELECT * FROM moncinema.customer;

DROP TABLE movie;
CREATE TABLE movie
AS SELECT * FROM moncinema.movie;

DROP TABLE movie_company;
CREATE TABLE movie_company
AS SELECT  * FROM moncinema.movie_company;

DROP TABLE sale;
CREATE TABLE sale
AS SELECT * FROM moncinema.sale;

DROP TABLE review;
CREATE TABLE review
AS SELECT * FROM moncinema.review;

DROP TABLE staff;
CREATE TABLE staff
AS SELECT * FROM moncinema.staff;

DROP TABLE movie_cinema;
CREATE TABLE movie_cinema
AS SELECT * FROM moncinema.movie_cinema;

DROP TABLE production_company;
CREATE TABLE production_company
AS SELECT * FROM moncinema.production_company;

DROP TABLE cinema_rating ;
CREATE TABLE cinema_rating
AS SELECT  * FROM moncinema.cinema_rating;

DROP TABLE genre;
CREATE TABLE genre
AS SELECT * FROM moncinema.genre;

DROP TABLE movie_genre;
CREATE TABLE movie_genre
AS SELECT * FROM moncinema.movie_genre;

DROP TABLE booking_mode;
CREATE TABLE booking_mode
AS SELECT * FROM moncinema.booking_mode;

DROP TABLE cinema;
CREATE TABLE cinema
AS SELECT * FROM moncinema.cinema;

SELECT
    *
FROM
     movie_company
WHERE
      movie_id NOT IN (SELECT movie_id FROM movie);


DELETE FROM movie_company
WHERE movie_id
NOT IN (SELECT movie_id FROM movie);

SELECT
       *
FROM
     cinema_rating
WHERE
      cinema_id NOT IN(SELECT cinema_id FROM cinema);

DELETE FROM cinema_rating
WHERE cinema_id
NOT IN (SELECT cinema_id FROM cinema);


SELECT
       *
FROM
     genre
WHERE
      genre_id IS NULL OR genre_description IS NULL;

DELETE FROM genre
WHERE genre_id IS NULL or genre_description IS NULL;

SELECT
       movie_id,
       count(*) as duplicates
FROM
     movie
GROUP BY
         movie_id
HAVING
       count(*) > 1;

DROP TABLE movie;
CREATE TABLE movie
AS SELECT DISTINCT *
FROM moncinema.movie;

SELECT
       *
FROM
     sale
WHERE
      sale_total_price < sale_unit_price;

DELETE FROM sale
WHERE sale_total_price < sale_unit_price;


SELECT
       company_id,
       count(*) as duplicates
FROM
     production_company
GROUP BY
         company_id
HAVING
       count (*) > 1;

DROP TABLE production_company;
CREATE TABLE production_company
AS SELECT DISTINCT *
FROM moncinema.production_company;

SELECT
    *
FROM
     movie_cinema
WHERE
    movie_id NOT IN (SELECT movie_id FROM movie)
    OR cinema_id NOT IN (SELECT cinema_id FROM cinema);

DROP TABLE movie_cinema;
CREATE TABLE movie_cinema AS
SELECT
    *
FROM
     moncinema.movie_cinema
WHERE
    movie_id IN (SELECT movie_id FROM movie)
    AND cinema_id IN (SELECT cinema_id FROM cinema);


SELECT *
FROM review
WHERE review_score < 0;

DELETE FROM review
WHERE review_score < 0;

SELECT
    *
FROM
    sale
WHERE
    mode_id =1
    AND staff_no IS NULL;

DELETE FROM SALE
WHERE mode_id =1 AND staff_no IS NULL;

SELECT
    *
FROM
    sale
WHERE
    sale_date > CURRENT_TIMESTAMP;

DELETE FROM SALE
WHERE sale_date > CURRENT_TIMESTAMP




